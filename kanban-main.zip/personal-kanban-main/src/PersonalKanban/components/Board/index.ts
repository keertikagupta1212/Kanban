import Board from "./Board";

export default Board;
