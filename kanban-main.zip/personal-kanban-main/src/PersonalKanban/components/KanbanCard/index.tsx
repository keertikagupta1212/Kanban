import KanbanCard from "./KanbanCard";

export default KanbanCard;
