import KanbanColumn from "./KanbanColumn";

export default KanbanColumn;
