import RecordForm from "./RecordForm";

export default RecordForm;
