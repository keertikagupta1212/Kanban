export const COLUMN_WIDTH = 250;
